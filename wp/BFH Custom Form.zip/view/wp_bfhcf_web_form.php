<?php 
$wpbfhcf_form_action = $_SERVER['PHP_SELF'] . '?' . $_SERVER['QUERY_STRING'];
if($wpbfhcf_message != null)
{
	echo $wpbfhcf_message;
}
?>

<ul class="nav nav-tabs">
  	<li>
  		<a href="#" onclick="javascript: wpbfch_code_view();"><span class="glyphicon glyphicon-edit"></span> Code View</a>
  	</li>
  	<li>
  		<a href="#" onclick="javascript: wpbfch_preview();"><span class="glyphicon glyphicon-envelope"></span> Preview</a>
  	</li>
</ul>
<br />
<div class="container" style="background-color: #fff;">
	<div class="row">
		<div class="col-sm-6">

			<div id="wpbfhcf_web_form_code_view">
				<form method="post" action="<?php echo $wpbfhcf_form_action ?>">
					<div class="form-group">
						<textarea name="wpbfhcf_txt_content" id="wpbfhcf_txt_content" class="form-control input-sm" style="resize: none;" rows="15"><?php echo $wpbfhcf_form; ?></textarea>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" value="Save Changes">
							<span class="glyphicon glyphicon-floppy-save"></span>
							Save Changes
						</button>
						<input type="hidden" name="wp_bfhcf_web_form_post" value="123<>099" />
					</div>
				</form>
			</div>

			<div id="wpbfhcf_web_form_preview" style="display: none;">
				<br />
				<?php echo wp_bfhcf_cleanup($wpbfhcf_form); ?>
				<hr />
				<p>
					<span class="glyphicon glyphicon-exclamation-sign"></span> 
					<small>Please save changes to view updated form display.</small>
				</p>
			</div>
		</div>
		<div class="col-sm-6">
			<div>

				<div class="form-group">
					<select class="form-control" name="wpbfhcf_selection_list" id="wpbfhcf_selection_list">
						<option value="1">Text Field</option>
						<option value="2">Textarea Field</option>
						<option value="3">Checkbox</option>
						<option value="4">Radio Button</option>
						<option value="5">Color Picker</option>
						<option value="6">Slider</option>
						<option value="7">Number Input</option>
						<option value="8">Date Picker</option>
						<option value="9">Select</option>
						<option value="10">Font Size</option>
						<option value="11">Font Picker</option>
						<option value="12">Google Font Picker</option>
						<option value="13">Submit Button</option>
						<option value="14">Phone Input</option>
						<option value="15">Time Picker</option>
						<option value="16">Language Picker</option>
						<option value="17">Currency Picker</option>
						<option value="18">Timezone Picker</option>
						<option value="19">State Picker</option>
						<option value="20">Country Picker</option>
					</select>
				</div>
				<div class="well text-right">
					<small id="wpbfhcf_source_code_generated" style="font-weight: bold;">&nbsp;</small>
				</div>


				<div id="wpbfhcf_property_panel_20" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_20" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Country:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Country" id="wpbfhcf_country_20" value="US" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_20();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_19" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_19" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Country:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Country" id="wpbfhcf_country_19" value="US" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>State:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="State" id="wpbfhcf_state_19" value="CA" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_19();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_18" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_18" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Country:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Country" id="wpbfhcf_country_18" value="US" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_18();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_17" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_17" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Country:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Country" id="wpbfhcf_country_17" value="US" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_17();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_16" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_16" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Language" id="wpbfhcf_language_16" value="en" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_16();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_15" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_15" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_15();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_14" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_14" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" id="wpbfhcf_value_14" value="5555555" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Format:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" id="wpbfhcf_format_14" value="+1 (ddd) ddd-dddd" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_14();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_13" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Class:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Class ..." id="wpbfhcf_class_13" value="btn btn-primary" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" id="wpbfhcf_value_13" value="Submit" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_13();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_12" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_12" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" value="Lato" id="wpbfhcf_data_font_12" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_12();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_11" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_11" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" value="Arial" id="wpbfhcf_data_font_11" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_11();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_10" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_10" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="8,10,12 ..." value="8,10,12,14,16" id="wpbfhcf_data_available_10" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_10();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_9" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_9" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_9();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_8" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_8" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control" id="wpbfhcf_value_8" value="m/d/y" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_8();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_7" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_7" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<form>
									<input type="text" class="form-control bfh-number" id="wpbfhcf_value_7" data-value="1" />
								</form>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Minimum:</label>
							</div>
							<div class="col-sm-8">
								<form>
									<input type="text" class="form-control bfh-number" id="wpbfhcf_min_7" />
								</form>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Maximum:</label>
							</div>
							<div class="col-sm-8">
								<form>
									<input type="text" class="form-control bfh-number" id="wpbfhcf_max_7" />
								</form>
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_7();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_6" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_6" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<form>
									<input type="text" class="form-control bfh-number" id="wpbfhcf_value_6" data-value="1" />
								</form>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Minimum:</label>
							</div>
							<div class="col-sm-8">
								<form>
									<input type="text" class="form-control bfh-number" id="wpbfhcf_min_6" />
								</form>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Maximum:</label>
							</div>
							<div class="col-sm-8">
								<form>
									<input type="text" class="form-control bfh-number" id="wpbfhcf_max_6" />
								</form>
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_6();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_5" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_5" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Placeholder:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Placeholder ..." id="wpbfhcf_placeholder_5" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Default Color:</label>
							</div>
							<div class="col-sm-8">
								<div class="bfh-colorpicker" input="form-control" data-name="colorpicker1" id="wpbfhcf_color_5"></div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Alignment:</label>
							</div>
							<div class="col-sm-8">
								<select class="form-control" name="wpbfhcf_align_5" id="wpbfhcf_align_5">
									<option value="left">Left</option>
									<option value="right">Right</option>
								</select>
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_5();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_4" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_4" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Class:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Class ..." id="wpbfhcf_class_4" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Default value ..." id="wpbfhcf_value_4" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Placeholder:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Placeholder ..." id="wpbfhcf_placeholder_4" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Inline stylesheet:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Inline stylesheet ..." id="wpbfhcf_stylesheet_4" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_4();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>


				<div id="wpbfhcf_property_panel_3" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_3" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Class:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Class ..." id="wpbfhcf_class_3" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Default value ..." id="wpbfhcf_value_3" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Placeholder:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Placeholder ..." id="wpbfhcf_placeholder_3" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Inline stylesheet:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Inline stylesheet ..." id="wpbfhcf_stylesheet_3" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_3();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>

				<div id="wpbfhcf_property_panel_2" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_2" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Class:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" value="form-control" placeholder="Class ..." id="wpbfhcf_class_2" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Default value ..." id="wpbfhcf_value_2" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Placeholder:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Placeholder ..." id="wpbfhcf_placeholder_2" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Rows:</label>
							</div>
							<div class="col-sm-8">
								<form>
									<input type="text" class="form-control bfh-number input-sm" data-zeros="true" data-min="1" data-max="30" id="wpbfhcf_rows_2" />
								</form>
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_2();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>

				<div id="wpbfhcf_property_panel_1" style="display: none;">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Field name &amp; id:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Field name &amp; id ..." id="wpbfhcf_name_id_1" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Class:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" value="form-control" placeholder="Class ..." id="wpbfhcf_class_1" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Value:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Default value ..." id="wpbfhcf_value_1" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Placeholder:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Placeholder ..." id="wpbfhcf_placeholder_1" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-4">
								<label>Inline stylesheet:</label>
							</div>
							<div class="col-sm-8">
								<input type="text" class="form-control input-sm" placeholder="Inline stylesheet ..." id="wpbfhcf_stylesheet_1" />
							</div>
						</div>
					</div>
					<div class="form-group">
						<button class="btn btn-primary" onclick="javascript:  wpbfhcf_generate_option_1();">
							<span class="glyphicon glyphicon-download-alt"></span>
							Generate Code 
						</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

