

<div class="container">
	<div class="row">

		<form method="post">
			<div class="col-md-4">

				<div class="form-group">
					<div class="row">
						<div class="col-md-4">
						<label>From:</label>
						</div>
						<div class="col-md-8">
						<input name="wp_bfhcf_txt_from" type="text" class="form-control input-sm" placeholder="Email from ..." value="<?php echo $from; ?>"  />
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col-md-4">
						<label>To:</label>
						</div>
						<div class="col-md-8">
						<input name="wp_bfhcf_txt_to" type="text" class="form-control input-sm" placeholder="Email to ..." value="<?php echo $to; ?>"  />
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
						<div class="col-md-4">
						<label>&nbsp;</label>
						</div>
						<div class="col-md-8">
							<button class="btn btn-primary">
							<span class="glyphicon glyphicon-floppy-disk"></span> 
							Save Changes
							</button>
						</div>
					</div>
				</div>
			
			</div>
			<div class="col-md-8">

				<div class="form-group">
					<div>
					<label>Subject:</label>
					</div>
					<div>
					<input name="wp_bfch_txt_subject" type="text" class="form-control input-sm" placeholder="Email subject ..." value="<?php echo $subject; ?>" />
					</div>
				</div>
				<div class="form-group">
					<div><label>Message body</label></div>
					<div>
					<textarea name="wp_bfch_txt_message" class="form-control input-sm" style="resize: none;" rows="10"><?php echo get_option(WP_BFHCF_EMAIL_TEMPLATE); ?></textarea>
					</div>
				</div>
			</div>
			<input type="hidden" name="WP_BFHCF_FORM_POST" value="2" />
		</form>

	</div>
</div>

