<div class="container">
	<h3><?php echo WP_BFHCF_TITLE; ?>: <small><i><?php echo $wpbfhcf_sub_title; ?></i></small></h3>
	<div class="alert alert-warning text-center">
		<small>
			<span class="glyphicon glyphicon-info-sign"></span> 
			Copy this code and paste it into your page content. 
			<b><?php echo WP_BFHCF_OPTION_NAME; ?></b>
		</small>
	</div>
</div>