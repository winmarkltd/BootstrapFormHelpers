<?php

function wp_bfhcf_controller()
{
	filter_var_array($_POST, FILTER_SANITIZE_STRING);
	filter_var_array($_GET, FILTER_SANITIZE_STRING);
	$view = null;
	if(isset($_GET['page']))
		$view = trim($_GET['page']);
	$wpbfhcf_panel = nulll;
	$wpbfhcf_sub_title = null;
	switch($view)
	{
		case 'wpbfhcf_web_form':
			$wpbfhch_message = wp_bfhcf_save_changes_on_form();
			$wpbfhcf_sub_title = 'WEB FORM';
			$wpbfhcf_form = get_option(WP_BFHCF_OPTION_NAME);
			$wpbfhcf_panel = WP_BFHCF_DIR . '/view/wp_bfhcf_web_form.php';
			break;
		case 'wpbfhcf_email_template':
			$wpbfhch_message = wp_bfhcf_save_changes_on_email_template();
			$wpbfhcf_sub_title = 'EMAIL TEMPLATE';
			$from = get_option(WP_BFHCF_EMAIL_FROM);
			$to = get_option(WP_BFHCF_EMAIL_TO);
			$subject = get_option(WP_BFHCF_EMAIL_SUBJECT);
			$wpbfhcf_panel = WP_BFHCF_DIR . '/view/wp_bfhcf_email_template.php';
			break;
	}
	require WP_BFHCF_DIR . '/view/wp_bfhcf_header.php';
	if($wpbfhcf_panel != null)
		require $wpbfhcf_panel;
	require WP_BFHCF_DIR . '/view/wp_bfhcf_footer.php';
}

