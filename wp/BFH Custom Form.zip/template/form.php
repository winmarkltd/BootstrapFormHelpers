<!-- Text Sample -->
<div>At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi.</div>
<!-- Full Name -->
<div class="form-group">
	<div><label>Full Name</label></div>
	<div>[[input type="text" name="txt_full_name" class="form-control input-sm" placeholder="Enter your full name" required /]]</div>
</div>
<!-- Email Address -->
<div class="form-group">
	<div><label>Email Address</label></div>
	<div>[[input type="text" name="txt_email" class="form-control input-sm" placeholder="Enter your email address" required /]]</div>
</div>
<!-- Color Selection -->
<div class="form-group">
	<div><label>Color</label></div>
	<div>[[div class="bfh-colorpicker" data-name="txt_color" data-color="#450eff" data-align="right"]][[/div]]</div>
</div>
<!-- Quantity -->
<div class="form-group">
	<div><label>Quantity</label></div>
	<div>[[input type="text" class="form-control bfh-number" data-name="txt_quantity" data-value="1" data-min="1" data-max="10" /]]</div>
</div>
<!-- Expected Delivery Date -->
<div class="form-group">
	<div><label>Expected Delivery Date</label></div>
	<div>[[div class="bfh-datepicker" data-name="txt_expected_delivery_date" data-value="m/d/y"]][[/div]]</div>
</div>
<!-- Instructions -->
<div class="form-group">
	<div><label>Instructions</label></div>
	<div>[[textarea name="txt_instructions" class="form-control" placeholder="Instructions" rows="5" style="resize: none;"]][[/textarea]]</div>
</div>
<hr />
<div class="form-group">
	[[input type="submit" value="Send My Order!" class="btn" /]]
</div>

<script language="javascript">
/*** begin SCRIPTS ***/

/*** end SCRIPTS ***/
</script>