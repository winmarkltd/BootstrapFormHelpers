
Hi!

Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

<b>ORDER DETAILS:</b>
<table>
<tbody>
<tr>
	<td><b>Name:</b></td>
	<td>[[txt_full_name]]</td>
</tr>
<tr>
	<td><b>Email Address:</b></td>
	<td>[[txt_email]]</td>
</tr>
<tr>
	<td><b>Color:</b></td>
	<td>[[txt_color]]</td>
</tr>
<tr>
	<td><b>Quantity:</b></td>
	<td>[[txt_quantity]]</td>
</tr>
<tr>
	<td><b>Expected Delivery Date:</b></td>
	<td>[[txt_expected_delivery_date]]</td>
</tr>
<tr>
	<td><b>Instructions:</b></td>
	<td>[[txt_instructions]]</td>
</tr>
</tbody>
</table>

Thank you!
[[txt_full_name]]