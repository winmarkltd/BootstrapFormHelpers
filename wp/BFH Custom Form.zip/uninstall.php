<?php

define('WP_BFHCF_OPTION_NAME', '[[wpbfhcf-form]]');
define('WP_BFHCF_EMAIL_TEMPLATE', '[[wpbfhcf-email-template]]');
define('WP_BFHCF_EMAIL_FROM', '[[wpbfhcf-email-from]]');
define('WP_BFHCF_EMAIL_TO', '[[wpbfhcf-email-to]]');
define('WP_BFHCF_EMAIL_SUBJECT', '[[wpbfhcf-email-subject]]');

if(defined('WP_UNINSTALL_PLUGIN') )
{
	delete_option(WP_BFHCF_OPTION_NAME);
	delete_option(WP_BFHCF_EMAIL_FROM);
	delete_option(WP_BFHCF_EMAIL_TO);
	delete_option(WP_BFHCF_EMAIL_SUBJECT);
	delete_option(WP_BFHCF_EMAIL_TEMPLATE);  
}

