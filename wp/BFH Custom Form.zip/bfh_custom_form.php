<?php
/**
 * Plugin Name: BFH Custom Form
 * Plugin URI: http://www.bootstrapformhelpers.com
 * Description: Just another contact form.
 * Version:  1.1
 * Author: Winmark
 * Author URI: http://www.winmarkltd.com
 * License: GPL2
 */

define('WP_BFHCF_OPTION_NAME', '[[wpbfhcf-form]]');
define('WP_BFHCF_TITLE', 'BFH Custom Form');
define('WP_BFHCF_VERSION', '1.0');
define('WP_BFHCF_BASEURL', plugins_url(null, __FILE__));
define('WP_BFHCF_CSS_DIR', WP_BFHCF_BASEURL . '/css/');
define('WP_BFHCF_IMG_DIR', WP_BFHCF_BASEURL . '/img/');
define('WP_BFHCF_JS_DIR', WP_BFHCF_BASEURL . '/js/');
define('WP_BFHCF_DIR', str_replace('\\' , '/', untrailingslashit(dirname(__FILE__))));
define('WP_BFHCF_TEMPLATE_DIR', WP_BFHCF_DIR . '/template/');
define('WP_BFHCF_INCLUDES_DIR', WP_BFHCF_DIR . '/includes/');
define('WP_BFHCF_EMAIL_TEMPLATE', '[[wpbfhcf-email-template]]');
define('WP_BFHCF_EMAIL_FROM', '[[wpbfhcf-email-from]]');
define('WP_BFHCF_EMAIL_TO', '[[wpbfhcf-email-to]]');
define('WP_BFHCF_EMAIL_SUBJECT', '[[wpbfhcf-email-subject]]');
$wp_bfhcf_includes_filename_list = array(
		'wp_bfhcf_controller.php',
		'wp_bfhcf_functions.php',
		'wp_bfhcf_defined.php'
	);
foreach($wp_bfhcf_includes_filename_list as $filename)
	require WP_BFHCF_INCLUDES_DIR . '/' . $filename;

wp_bfhcf_scripts();
add_action('admin_menu', 'wpbfhcf_dashboard_menu' );
add_action('the_content', 'wp_bfhcf_update_content');
add_option(WP_BFHCF_OPTION_NAME, file_to_variable('form.php'));
add_option(WP_BFHCF_EMAIL_FROM, 'email_from@example.com');
add_option(WP_BFHCF_EMAIL_TO, 'email_to@example.com');
add_option(WP_BFHCF_EMAIL_SUBJECT, 'Sample email order by [[txt_full_name]]');
add_option(WP_BFHCF_EMAIL_TEMPLATE, file_to_variable('email.php'));

function file_to_variable($template)
{
    ob_start();
    require(WP_BFHCF_TEMPLATE_DIR . $template);
    return ob_get_clean();
}

function wpbfhcf_dashboard_menu()
{
	if(! is_admin()) exit();
	$title = WP_BFHCF_TITLE . ' VERSION ' . WP_BFHCF_VERSION;
    add_menu_page($title, WP_BFHCF_TITLE, null, 'wpbfhcf_dashboard', 
    	'wp_bfhcf_controller', null, 75);
    add_submenu_page('wpbfhcf_dashboard', $title, 'Web Form', 'manage_options', 'wpbfhcf_web_form', 'wp_bfhcf_controller');
    add_submenu_page('wpbfhcf_dashboard', $title, 'Email Template', 'manage_options', 'wpbfhcf_email_template', 'wp_bfhcf_controller');
}

function wp_bfhcf_scripts()
{
	if(is_admin())
	{
    	wp_enqueue_style( 'bfh-bootstrap-css', 'http://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css');
		wp_enqueue_style( 'bfh-bootstrap-formhelpers-css', WP_BFHCF_CSS_DIR . 'bootstrap-formhelpers.css');
		wp_enqueue_script('jquery');
	  	wp_enqueue_script( 'bootstrap-formhelpers-js', WP_BFHCF_JS_DIR . 'bootstrap-formhelpers.js');
	  	wp_enqueue_script( 'default-js', WP_BFHCF_JS_DIR . 'default.js');
	}
	else
	{
		wp_enqueue_style( 'bfh-bootstrap-formhelpers-css', WP_BFHCF_CSS_DIR . 'bootstrap-formhelpers.css');
		wp_enqueue_script('jquery');
	  	wp_enqueue_script( 'bootstrap-formhelpers-js', WP_BFHCF_JS_DIR . 'bootstrap-formhelpers.js');
	}
}

function wp_bfhcf_save_changes_on_form()
{
	if(! is_admin()) exit();
	if(isset($_POST['wpbfhcf_txt_content']) && isset($_POST['wp_bfhcf_web_form_post']))
	{
		$new_value = stripslashes(trim($_POST['wpbfhcf_txt_content']));
		update_option(WP_BFHCF_OPTION_NAME, $new_value);
		$message = 'record has been updated!';
		return $message;
	}
	return null;
}

function wp_bfhcf_cleanup($value)
{
	$value = str_replace('[[', '<', $value);
	$value = str_replace(']]', '>', $value);
	$value = str_replace('/]]', ' />', $value);
	return $value;
}

function wp_bfhcf_update_content($content)
{
	filter_var_array($_POST, FILTER_SANITIZE_STRING);
	filter_var_array($_GET, FILTER_SANITIZE_STRING);
	if(strtoupper($_SERVER['REQUEST_METHOD']) != 'POST') 
	{
		$wpbfhcf_form_content = get_option(WP_BFHCF_OPTION_NAME);
		$wpbfhcf_form_content = wp_bfhcf_cleanup($wpbfhcf_form_content);
		$wpbfhcf_form_content = '<form method="post" name="WP_BFHCF_FORM" id="WP_BFHCF_FORM">' 
			. $wpbfhcf_form_content 
			. '<input type="hidden" name="WP_BFHCF_FORM_POST" value="1" />'
			. '</form>';
		$content = str_replace(WP_BFHCF_OPTION_NAME, $wpbfhcf_form_content, $content);
	} 
	else
	{
		if(isset($_POST['WP_BFHCF_FORM_POST']))
			if($_POST['WP_BFHCF_FORM_POST'] == 1)
			{
				$msg = '<div class="alert alert-info"><span class="glyphicon glyphicon-info-sign"></span> Thank you!</div>';
						$content = str_replace(WP_BFHCF_OPTION_NAME, $msg, $content);
				wp_bfhcf_send_email();
			}
	}

	return $content;
}

function wp_bfhcf_send_email()
{
	add_filter( 'wp_mail_content_type', function ($content_type){
			return 'text/html';
		});
	$message = get_option(WP_BFHCF_EMAIL_TEMPLATE);
	$from = get_option(WP_BFHCF_EMAIL_FROM);
	$to = get_option(WP_BFHCF_EMAIL_TO);
	$subject = get_option(WP_BFHCF_EMAIL_SUBJECT);
	foreach($_POST as $n => $v)
	{
		$subject = str_replace('[[' . $n . ']]', trim($v), $subject);
		$message = str_replace('[[' . $n . ']]', trim($v), $message);
	}
	$headers = 'From:' . $from;
	wp_mail($to, $subject, $message, $headers);
}

function wp_bfhcf_save_changes_on_email_template()
{
	if(! is_admin()) exit();
	if(isset($_POST['WP_BFHCF_FORM_POST']) && $_POST['WP_BFHCF_FORM_POST'] == 2)
	{
		$from = $_POST['wp_bfhcf_txt_from'];
		$to = $_POST['wp_bfhcf_txt_to'];
		$subject = $_POST['wp_bfch_txt_subject'];
		$message = $_POST['wp_bfch_txt_message'];
		update_option(WP_BFHCF_EMAIL_FROM, $from);
		update_option(WP_BFHCF_EMAIL_TO, $to);
		update_option(WP_BFHCF_EMAIL_SUBJECT, $subject);
		update_option(WP_BFHCF_EMAIL_TEMPLATE, $message);
		$message = 'record has been updated!';
		return $message;
	}
	return null;
}

